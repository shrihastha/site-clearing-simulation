package com.oracle;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SiteClearingSimulation {
	private List<List<Character>> siteMap = new ArrayList<>();
	private List<String> commands = new ArrayList<>();
	private Item item = new Item();
	private int x = 0;
	private int y = -1;
	private int facing = Directions.E.label;
	private int blocksMoved;

	public static void main(String[] args) {
		SiteClearingSimulation siteClearingSimulation = new SiteClearingSimulation();
		if (args.length > 0) {
			siteClearingSimulation.readConstructionSiteMap(args[0]);
			System.out.println("Welcome to the Aconex site clearing simulator. This is a map of the site:");
			siteClearingSimulation.printConstructionSiteMap();
			System.out.println(
					"The bulldozer is currently located at the Northern edge of the site, immediately to the West of the site, and facing East.");
			System.out.println("(l)eft, (r)ight, (a)dvance <n>, (q)uit:");
			siteClearingSimulation.takeInstructions();
			System.out.println("These are the commands you issued:");
			siteClearingSimulation.printUserCommands();
			System.out.println("The costs for this land clearing operation were:");
			siteClearingSimulation.calculateCost();
			System.out.println("Thank you for using the Aconex site clearing simulator.");
		} else {
			System.err.println("Please pass the file path as a command line argument.");
		}
	}

	public void readConstructionSiteMap(String fileName) {
		File file = new File(fileName);
		try (Scanner sc = new Scanner(file)) {
			while (sc.hasNextLine()) {
				String row = sc.nextLine();
				List<Character> rowList = new ArrayList<>();
				for (int i = 0; i < row.length(); i++) {
					rowList.add(row.charAt(i));
				}
				siteMap.add(rowList);
			}
		} catch (final FileNotFoundException e) {
			System.err.println("The file does not exist in the specified path. Please pass correct file path.");
		}
	}

	private void printConstructionSiteMap() {
		siteMap.forEach(row -> {
			row.forEach(squareBlock -> System.out.print(squareBlock));
			System.out.print("\n");
		});
	}

	private void takeInstructions() {
		try (Scanner in = new Scanner(System.in)) {
			while (in.hasNextLine()) {
				String command = in.nextLine().trim();
				commands.add(command);
				if (command.equals(UserInputs.q.name())) {
					System.out.print("The simulation has ended at your request.");
					break;
				} else {
					boolean isSuccess = startClearingTheSite(command);
					if (!isSuccess) {
						break;
					}
				}
			}
		}
	}

	public boolean startClearingTheSite(String command) {
		boolean isSuccess = true;
		item.setCommunicationCount(item.getCommunicationCount() + 1);
		if (command.equals(UserInputs.l.name())) {
			turnLeft();
		} else if (command.equals(UserInputs.r.name())) {
			turnRight();
		} else {
			String[] advance = command.split(" ");
			if (advance.length == 2 && advance[0].equals(UserInputs.a.name())) {
				try {
					Integer positions = Integer.valueOf(advance[1]);
					isSuccess = move(positions);
				} catch (final NumberFormatException nfe) {
					System.err.println("Invalid command. Please enter a valid command");
				}
			} else {
				System.err.println("Invalid command. Please enter a valid command");
			}
		}
		return isSuccess;
	}

	private void printUserCommands() {
		String userCommands = commands.stream()
				.map(command -> command.startsWith(UserInputs.a.name())
						? UserInputs.a.label + " " + command.charAt(command.length() - 1)
						: UserInputs.valueOf(command).label)
				.collect(Collectors.joining(", "));
		System.out.println(userCommands);
	}

	private void turnLeft() {
		facing = (facing - 1) < Directions.N.label ? Directions.W.label : facing - 1;
	}

	private void turnRight() {
		facing = (facing + 1) > Directions.W.label ? Directions.N.label : facing + 1;
	}

	private boolean move(int positions) {
		boolean isMoveSuccess = true;
		for (int i = 0; i < positions; i++) {
			if (facing == Directions.N.label) {
				this.x--;
			} else if (facing == Directions.E.label) {
				this.y++;
			} else if (facing == Directions.S.label) {
				this.x++;
			} else if (facing == Directions.W.label) {
				this.y--;
			}

			// Check if there is an attempt to navigate beyond the boundaries of the site
			if (x >= siteMap.size() || x == -1 || y == -1 || y >= siteMap.get(0).size()) {
				isMoveSuccess = false;
				System.err.println("There was an attempt to navigate beyond the boundaries of the site.");
				break;
			} else if (siteMap.get(x).get(y) == Blocks.T.label) {
				isMoveSuccess = false;
				item.setProtectedTreeRemovalCount(1);
				System.err.println("There was an attempt to remove a tree that is protected.");
				break;
			}
			blocksMoved += 1;
			// Add Item
			addItem();
		}
		return isMoveSuccess;
	}

	private void addItem() {
		int fuelUnit = item.getFuelUnit();
		switch (Blocks.valueOf(String.valueOf(siteMap.get(x).get(y)))) {
		case o:
			item.setFuelUnit(++fuelUnit);
			break;
		case t:
			item.setFuelUnit(fuelUnit + 2);
			siteMap.get(x).set(y, Blocks.o.label);
			break;
		case r:
			item.setFuelUnit(fuelUnit + 2);
			siteMap.get(x).set(y, Blocks.o.label);
			break;
		default:
			break;
		}
	}

	public int calculateCost() {
		int totalCost = 0;
		int communicationCost = item.getCommunicationCount();
		int fuelUnit = item.getFuelUnit();
		int protectedTreeCount = item.getProtectedTreeRemovalCount();
		int protectedTreeDesCost = protectedTreeCount * 10;
		int unclearedSquares = unclearedSquares();
		int unclearedSquaresCharges = unclearedSquares * 3;
		totalCost = communicationCost + fuelUnit + unclearedSquaresCharges + protectedTreeDesCost;
		displayCost(communicationCost, fuelUnit, unclearedSquares, unclearedSquaresCharges, protectedTreeDesCost,
				protectedTreeCount, totalCost);
		return totalCost;
	}

	private void displayCost(int communicationCost, int fuelUnit, int unclearedSquares, int unclearedSquaresCharges,
			int protectedTreeDesCost, int protectedTreeCount, int totalCost) {
		System.out.println("Item\t\t\t\tQuantity\tCost");
		System.out.println("communication overhead\t\t" + communicationCost + "\t\t" + communicationCost);
		System.out.println("fuel usage\t\t\t" + fuelUnit + "\t\t" + fuelUnit);
		System.out.println("uncleared squares\t\t" + unclearedSquares + "\t\t" + unclearedSquaresCharges);
		System.out.println("destruction of protected tree\t" + protectedTreeCount + "\t\t" + protectedTreeDesCost);
		System.out.println("-----------------------------------------------------");
		System.out.println("Total- \t\t\t\t\t\t" + totalCost);
	}

	private int unclearedSquares() {
		int rowCount = siteMap.size();
		int columnCount = siteMap.get(0).size();
		int protectedTreeCount = 0;
		for (List<Character> row : siteMap) {
			for (Character block : row) {
				if (block == Blocks.T.label) {
					protectedTreeCount += 1;
				}
			}
		}
		int unclearedSquares = rowCount * columnCount - blocksMoved - protectedTreeCount;
		return unclearedSquares;
	}

	public enum UserInputs {
		a("advance"), l("left"), r("right"), q("quit");
		public final String label;

		private UserInputs(String label) {
			this.label = label;
		}
	}

	public enum Directions {
		N(1), E(2), S(3), W(4);
		public final int label;

		private Directions(int label) {
			this.label = label;
		}
	}

	public enum Blocks {
		o('o'), t('t'), T('T'), r('r');
		public final char label;

		private Blocks(char label) {
			this.label = label;
		}
	}
}
