package com.oracle;

public class Item {
	private int fuelUnit;
	private int communicationCount;
	private int protectedTreeRemovalCount;

	public int getFuelUnit() {
		return fuelUnit;
	}

	public void setFuelUnit(int fuelUnit) {
		this.fuelUnit = fuelUnit;
	}

	public int getCommunicationCount() {
		return communicationCount;
	}

	public void setCommunicationCount(int communicationCount) {
		this.communicationCount = communicationCount;
	}

	public int getProtectedTreeRemovalCount() {
		return protectedTreeRemovalCount;
	}

	public void setProtectedTreeRemovalCount(int protectedTreeRemovalCount) {
		this.protectedTreeRemovalCount = protectedTreeRemovalCount;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Item [fuelUnit=").append(fuelUnit).append(", communicationCount=").append(communicationCount)
				.append(", protectedTreeRemovalCount=").append(protectedTreeRemovalCount).append("]");
		return builder.toString();
	}

}
