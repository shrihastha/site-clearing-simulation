package com.oracle;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Site Clearing Simulation Test")
public class SiteClearingSimulationTest {
	SiteClearingSimulation siteClearingSimulation;

	@BeforeEach
	public void loadSiteMap() {
		// Given
		siteClearingSimulation = new SiteClearingSimulation();
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("sitemap.txt").getFile());
		siteClearingSimulation.readConstructionSiteMap(file.getAbsolutePath());
	}

	@Test
	@DisplayName("Move through removable trees")
	public void calculateTotalCost1() {
		// When
		siteClearingSimulation.startClearingTheSite("a 2");
		siteClearingSimulation.startClearingTheSite("a 1");

		// Then
		assertEquals(141, siteClearingSimulation.calculateCost());
	}

	@Test
	@DisplayName("Attempt to remove a tree that is protected")
	public void calculateTotalCost2() {
		// When
		siteClearingSimulation.startClearingTheSite("a 8");
		siteClearingSimulation.startClearingTheSite("r");
		siteClearingSimulation.startClearingTheSite("a 1");

		// Then
		assertEquals(142, siteClearingSimulation.calculateCost());
	}

	@Test
	@DisplayName("Clearing rocks in the site")
	public void calculateTotalCost3() {
		// When
		siteClearingSimulation.startClearingTheSite("a 2");
		siteClearingSimulation.startClearingTheSite("r");
		siteClearingSimulation.startClearingTheSite("a 4");

		// Then
		assertEquals(138, siteClearingSimulation.calculateCost());
	}

	@Test
	@DisplayName("Attempt to navigate beyond the boundaries of the site")
	public void calculateTotalCost4() {
		// When
		siteClearingSimulation.startClearingTheSite("a 1");
		siteClearingSimulation.startClearingTheSite("l");
		siteClearingSimulation.startClearingTheSite("a 1");

		// Then
		assertEquals(145, siteClearingSimulation.calculateCost());
	}
}
